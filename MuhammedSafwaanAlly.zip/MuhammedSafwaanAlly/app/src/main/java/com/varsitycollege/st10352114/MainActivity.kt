package com.varsitycollege.st10352114

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
//www.youtube.com. (n.d.). Simple Calculator Using Kotlin. [online] Available at:
// https://youtu.be/Zi1XgFTUH9k?si=sk9QqMEiyEKlXN6g [Accessed 24 Aug. 2023].


class MainActivity : AppCompatActivity() {

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //setting our variables and view by ids
//creating our calculator buttons and assigning them

        val number1 = findViewById<EditText>(R.id.Number1)
        val number2 = findViewById<EditText>(R.id.Number2)
        val answerTextView = findViewById<TextView>(R.id.Answer)
        val multiplicationButton = findViewById<Button>(R.id.Multiplication)
        val divisionButton = findViewById<Button>(R.id.Division)
        val subtractionButton = findViewById<Button>(R.id.Subtraction)
        val additionButton = findViewById<Button>(R.id.Addition)

//setting on click listeners for each of our calculator buttons
        multiplicationButton.setOnClickListener {

            //i used the toInt() function to convert to an integer and allows for return
            val multiplynumber1 = number1.text.toString().toInt()
            val multiplynumber2 = number2.text.toString().toInt()

            val answer = multiplynumber1 * multiplynumber2
            //i used the $ to get the exact value of the answer and the 2 numbers
            answerTextView.text = "$multiplynumber1 * $multiplynumber2 = $answer"
        }

        divisionButton.setOnClickListener {

            val dividenumber1 = number1.text.toString().toInt()
            val dividenumber2 = number2.text.toString().toInt()

            val answer = dividenumber1 / dividenumber2
            answerTextView.text = "$dividenumber1 / $dividenumber2 = $answer"
        }

        subtractionButton.setOnClickListener {

            val minusnumber1 = number1.text.toString().toInt()
            val minusnumber2 = number2.text.toString().toInt()

            val answer = minusnumber1 - minusnumber2
            answerTextView.text = "$minusnumber1 - $minusnumber2 = $answer"
        }

        additionButton.setOnClickListener {

            val addnumber1 = number1.text.toString().toInt()
            val addnumber2 = number2.text.toString().toInt()

            val answer = addnumber1 + addnumber2
            answerTextView.text = "$addnumber1 + $addnumber2 = $answer"
        }

    }
}

